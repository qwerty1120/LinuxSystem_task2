#include "repo_header.h"
int main(int argc, char *argv[]){
    printf("revert.c call\n");
    for(int i=0;i<argc;i++){
        printf("%d. %s\n", i, argv[i]);
    }
}
#include "repo_header.h"
int main(int argc, char *argv[]){
    char buf[PATHMAX*4];
    Get_Path();//초기 세팅

    if(argc == 1){//인자 없을 때
        if(Print_Log("")){//전체 기록 출력
            printf("commit log is not exist\n");//기록이 없을때
            exit(1);
        }
    }
    else if(argc > 1){
        strcpy(buf, argv[1]);
        for(int i=2;i<argc;i++){//띄어쓰기 경우 생각해서 이어주기
            strcat(buf, " ");
            strcat(buf, argv[i]);
        }
//        sprintf(buf, "%s", buf+1);
//        buf[strlen(buf)-1]=0;//todo 따옴표 처리

        if(strlen(buf)>STRMAX){//길이 체크
            fprintf(stderr, "Input path must not exceed 255 bytes.\n");
            exit(1);
        }
        if(Print_Log(buf)){//특정 커밋 기록 출력
            printf("\"%s\" commit log is not exist\n", buf);//없을때
            exit(1);
        }
    }
}
#include "repo_header.h"

int main(int argc, char *argv[]){
    Get_Path();
    Stag_Setting();//초기 세팅

    if(argc<2){//경로 안들어옴
        printf("ERROR : <PATH> is not include\n");
        printf("Usage : add <PATH>: record path to staging area, path will track modification.\n");
        exit(1);
    }
    if(strlen(argv[1])>PATHMAX){//너무 김
        fprintf(stderr, "Input path must not exceed 4,096 bytes.\n");
        exit(1);
    }

    if(realpath(argv[1], FILEPATH)==NULL){//잘못된 경로
        fprintf(stderr, "ERROR : \"%s\" is wrong path.\n", argv[1]);
        exit(1);
    }

    if (strncmp(FILEPATH, EXEPATH, strlen(EXEPATH))
        || !strncmp(FILEPATH, REPOPATH, strlen(REPOPATH)))  {// 사용자 디렉토리 내부의 경로인지 확인
        fprintf(stderr, "ERROR: path must be in user directory\n - \'%s\' is not in user directory.\n", FILEPATH);
        exit(1);
    }

    struct Node * check = Find_Node(FILEPATH, Q->head);
    if(Check_Status(check, ADD_CMD) == 0){//명령어 중복 체크
        printf("\".%s\" is already exist in staging area.\n", FILEPATH+strlen(EXEPATH));
        exit(1);
    }
    //스테이징 로그에 입력
    int fd;

    if((fd=open(STAGPATH, O_RDWR|O_APPEND)) < 0){
        fprintf(stderr, "open error for %s\n", STAGPATH);
        exit(1);
    }

    snprintf(BUF, strlen(FILEPATH)+8, "add \"%s\"\n", FILEPATH);

    if(write(fd, BUF, strlen(BUF)) < 0){
        fprintf(stderr, "write error for %s\n", STAGPATH);
        exit(1);
    }

    printf("add \".%s\"\n", FILEPATH+strlen(EXEPATH));
    exit(0);
}
#include "repo_header.h"

int main(int argc, char *argv[]){
    char buf[PATHMAX*4];
    Get_Path();
    Stag_Setting();//초기 세팅

    if(argc<2){//이름 안들어옴
        printf("ERROR : <NAME> is not include\n");
        printf("Usage : commit <NAME>: backup staging area with commit name.\n");
        exit(1);
    }
    strcpy(buf, argv[1]);
    for(int i=2;i<argc;i++){//이름이 띄어쓰기로 있는 경우 합쳐주기
        strcat(buf, " ");
        strcat(buf, argv[i]);
    }

    //        sprintf(buf, "%s", buf+1);
    //        buf[strlen(buf)-1]=0;//todo 따옴표 처리

    if(strlen(buf)>STRMAX){//길이 체크
        fprintf(stderr, "Input path must not exceed 255 bytes.\n");
        exit(1);
    }

    int cnt;
    struct dirent **namelist;

    if ((cnt = scandir(".repo", &namelist, NULL, alphasort)) == -1) {//디렉토리 스캔해서
        fprintf(stderr, "ERROR : scandir error for .repo\n");
        exit(1);
    }
    for (int i = 0; i < cnt; i++) {
        if (!strcmp(namelist[i]->d_name, ".") || !strcmp(namelist[i]->d_name, ".."))
            continue;
        if(!strcmp(buf, namelist[i]->d_name)){//같은 이름의 커밋있는 지 확인
            printf("\"%s\" commit is already exist in repo.\n", buf);
            exit(1);
        }
    }
    Commit(buf);//없으면 실행
}
#include "repo_header.h"
int main(int argc, char *argv[]){
    Get_Path();
    Stag_Setting();//초기 세팅

    if(argc>1){//다른 인자 들어오면 안됌
        printf("Usage : status: show staging area status.\n");
        exit(1);
    }

    Print_Status();//실행
}